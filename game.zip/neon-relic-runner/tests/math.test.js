import test from 'node:test';
import assert from 'node:assert/strict';
import { clamp, distance2D, formatTime, seedRandom, smoothTowards, hitCircle } from '../src/math.js';

test('clamp respects both limits',()=>{
  assert.equal(clamp(-4,0,10),0);
  assert.equal(clamp(12,0,10),10);
  assert.equal(clamp(4,0,10),4);
});
test('distance is based on x and z',()=>{
  assert.equal(distance2D({x:0,z:0},{x:3,z:4}),5);
});
test('seconds format with leading zeros',()=>{
  assert.equal(formatTime(65.9),'1:05');
  assert.equal(formatTime(-3),'0:00');
});
test('seeded random generation is repeatable',()=>{
  const first=seedRandom(123);
  const second=seedRandom(123);
  for(let i=0;i<40;i++)assert.equal(first(),second());
});
test('smooth response moves toward target',()=>{
  assert.ok(smoothTowards(0,10,5,.1)>0);
  assert.ok(smoothTowards(0,10,5,.1)<10);
});
test('circle collision tests overlap',()=>{
  assert.equal(hitCircle({x:0,z:0},1,{x:1,z:0},1),true);
  assert.equal(hitCircle({x:0,z:0},1,{x:5,z:0},1),false);
});
