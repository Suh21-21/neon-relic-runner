import * as THREE from 'three';
import { clamp, smoothTowards } from './math.js';
import { isObstacleAt } from './world.js';

export class Player {
  constructor(scene,spawn) {
    this.group=new THREE.Group();
    const armor=new THREE.MeshStandardMaterial({color:0x82c9ff,metalness:.68,roughness:.25});
    const detail=new THREE.MeshStandardMaterial({color:0x60fff0,emissive:0x27d9dc,emissiveIntensity:1.7});
    const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.44,.68,6,12),armor);
    torso.position.y=1.13;
    torso.castShadow=true;
    this.group.add(torso);
    const visor=new THREE.Mesh(new THREE.BoxGeometry(.62,.18,.12),detail);
    visor.position.set(0,1.56,.38);
    this.group.add(visor);
    const shadow=new THREE.Mesh(new THREE.CircleGeometry(.55,24),new THREE.MeshBasicMaterial({color:0x041126,transparent:true,opacity:.35}));
    shadow.rotation.x=-Math.PI/2;
    shadow.position.y=.015;
    this.group.add(shadow);
    this.group.position.set(spawn.x,0,spawn.z);
    scene.add(this.group);
    this.position={x:spawn.x,z:spawn.z};
    this.velocityY=0;
    this.jumpHeight=0;
    this.invulnerable=0;
    this.radius=.42;
    this.heading=0;
  }
  update(input,world,delta) {
    this.invulnerable=Math.max(0,this.invulnerable-delta);
    const vx=Number(input.right)-Number(input.left);
    const vz=Number(input.down)-Number(input.up);
    const len=Math.hypot(vx,vz)||1;
    const speed=input.sprint?8.1:5.4;
    const dx=vx/len*speed*delta;
    const dz=vz/len*speed*delta;
    if(vx!==0||vz!==0) {
      const nextX={x:this.position.x+dx,z:this.position.z};
      const nextZ={x:this.position.x,z:this.position.z+dz};
      if(!isObstacleAt(nextX,this.radius,world))this.position.x=nextX.x;
      if(!isObstacleAt(nextZ,this.radius,world))this.position.z=nextZ.z;
      this.heading=smoothTowards(this.heading,Math.atan2(vx,vz),15,delta);
      this.group.rotation.y=this.heading;
    }
    let jumped=false;
    if(input.jump && this.jumpHeight<=0.001) {
      this.velocityY=7.1;
      jumped=true;
    }
    if(this.jumpHeight>0||this.velocityY>0) {
      this.velocityY-=19*delta;
      this.jumpHeight=clamp(this.jumpHeight+this.velocityY*delta,0,5);
      if(this.jumpHeight===0)this.velocityY=0;
    }
    this.group.position.set(this.position.x,this.jumpHeight,this.position.z);
    this.group.visible=this.invulnerable===0 || Math.floor(this.invulnerable*12)%2===0;
    return jumped;
  }
  damage() {this.invulnerable=1.35;}
  get airborne() {return this.jumpHeight>.58;}
  dispose(scene) {scene.remove(this.group);}
}
