import * as THREE from 'three';
import { seedRandom } from './math.js';

const MATERIALS = {
  floor: new THREE.MeshStandardMaterial({color:0x17223a, metalness:.35, roughness:.65}),
  rim: new THREE.MeshStandardMaterial({color:0x37f4d5, emissive:0x11b49d, emissiveIntensity:1.8}),
  obstacle: new THREE.MeshStandardMaterial({color:0x354164, metalness:.5, roughness:.45}),
  purple: new THREE.MeshStandardMaterial({color:0xa967ff, emissive:0x6c2adb, emissiveIntensity:1.3}),
  crystal: new THREE.MeshStandardMaterial({color:0x85fce9, emissive:0x18cba9, emissiveIntensity:1.5, metalness:.3, roughness:.2}),
  enemy: new THREE.MeshStandardMaterial({color:0xff728c, emissive:0xda1645, emissiveIntensity:1.2}),
  portalOff: new THREE.MeshStandardMaterial({color:0x4c5c7c, emissive:0x131d33, emissiveIntensity:.5}),
  portalOn: new THREE.MeshStandardMaterial({color:0xffc96e, emissive:0xffa329, emissiveIntensity:2.1})
};

function box(width, height, depth, material, x=0, y=0, z=0) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(width,height,depth),material);
  mesh.position.set(x,y,z);
  mesh.castShadow=true;
  mesh.receiveShadow=true;
  return mesh;
}
function edgeOutline(mesh, color=0x5d8fae) {
  const edges = new THREE.LineSegments(new THREE.EdgesGeometry(mesh.geometry), new THREE.LineBasicMaterial({color,transparent:true,opacity:.42}));
  mesh.add(edges);
}
function crystal(x,z) {
  const group = new THREE.Group();
  const mesh = new THREE.Mesh(new THREE.OctahedronGeometry(.47), MATERIALS.crystal);
  mesh.castShadow=true;
  group.add(mesh);
  group.position.set(x,1.25,z);
  const glow = new THREE.PointLight(0x32ffe1,1.4,4);
  group.add(glow);
  return {mesh:group,position:{x,z},collected:false};
}
function sentinel(x,z,phase,speed,axis) {
  const group=new THREE.Group();
  const body=new THREE.Mesh(new THREE.IcosahedronGeometry(.67,1),MATERIALS.enemy);
  group.add(body);
  const core=new THREE.Mesh(new THREE.OctahedronGeometry(.25),MATERIALS.purple);
  group.add(core);
  group.position.set(x,1.06,z);
  const light=new THREE.PointLight(0xff386b,2.2,5);
  group.add(light);
  return {mesh:group,origin:{x,z},phase,speed,axis,position:{x,z}};
}
function portal(x,z) {
  const group=new THREE.Group();
  const material=MATERIALS.portalOff.clone();
  const ring=new THREE.Mesh(new THREE.TorusGeometry(1.15,.13,12,56),material);
  ring.rotation.x=Math.PI/2;
  ring.position.y=.11;
  group.add(ring);
  const center=new THREE.Mesh(new THREE.CylinderGeometry(.85,.85,.06,48),new THREE.MeshBasicMaterial({color:0x75829e,transparent:true,opacity:.45}));
  center.position.y=.03;
  group.add(center);
  group.position.set(x,.08,z);
  const beam=new THREE.PointLight(0xffbd5b,0,7);
  beam.position.y=1;
  group.add(beam);
  return {mesh:group,ring,beam,active:false,position:{x,z}};
}
export function generateWorld(scene,level=1) {
  const random=seedRandom(4517+level*923);
  const size=26+Math.min(level-1,4)*4;
  const half=size/2;
  const group=new THREE.Group();
  scene.add(group);
  const floor=box(size,.7,size,MATERIALS.floor,0,-.48,0);
  group.add(floor);
  edgeOutline(floor,0x18d9d3);
  const grid=new THREE.GridHelper(size,size,0x30a6ad,0x24405d);
  grid.position.y=-.11;
  group.add(grid);
  const borderPieces=[
    box(size,.25,.22,MATERIALS.rim,0,.05,-half),
    box(size,.25,.22,MATERIALS.rim,0,.05,half),
    box(.22,.25,size,MATERIALS.rim,-half,.05,0),
    box(.22,.25,size,MATERIALS.rim,half,.05,0)
  ];
  borderPieces.forEach(piece=>group.add(piece));
  const obstacles=[];
  const occupied=[{x:-half+3,z:-half+3},{x:half-3,z:half-3}];
  for(let i=0;i<10+level*3;i++) {
    const w=1.3+random()*2;
    const d=1.3+random()*2;
    const x=(random()-.5)*(size-7);
    const z=(random()-.5)*(size-7);
    if(occupied.some(point=>Math.hypot(point.x-x,point.z-z)<4))continue;
    if(Math.abs(x-z)<2.8 && random()<.8)continue;
    const height=.8+random()*2;
    const block=box(w,height,d,MATERIALS.obstacle,x,height/2-.13,z);
    edgeOutline(block,0x6279b5);
    group.add(block);
    obstacles.push({x,z,w,d,height});
    occupied.push({x,z});
  }
  const crystals=[];
  for(let attempt=0;attempt<240 && crystals.length<5+level*2;attempt++) {
    const x=(random()-.5)*(size-5);
    const z=(random()-.5)*(size-5);
    if(occupied.some(point=>Math.hypot(point.x-x,point.z-z)<2.3))continue;
    const item=crystal(x,z);
    crystals.push(item);
    group.add(item.mesh);
    occupied.push({x,z});
  }
  const enemies=[];
  for(let attempt=0;attempt<80 && enemies.length<2+level;attempt++) {
    const x=(random()-.5)*(size-9);
    const z=(random()-.5)*(size-9);
    if(occupied.some(point=>Math.hypot(point.x-x,point.z-z)<3.3))continue;
    const enemy=sentinel(x,z,random()*Math.PI*2,.6+random()*.6,random()>.5?'x':'z');
    enemies.push(enemy);
    group.add(enemy.mesh);
    occupied.push({x,z});
  }
  const exit=portal(half-3,half-3);
  group.add(exit.mesh);
  const start={x:-half+3,z:-half+3};
  const decoration=new THREE.Group();
  for(let i=0;i<90;i++){
    const x=(random()-.5)*(size+33),z=(random()-.5)*(size+33);
    if(Math.abs(x)<half+2 && Math.abs(z)<half+2)continue;
    const h=.5+random()*5;
    decoration.add(box(.15,h,.15,MATERIALS.purple,x,-h/2-.5,z));
  }
  group.add(decoration);
  return {group,crystals,enemies,obstacles,exit,start,size};
}
export function isObstacleAt(position,radius,world) {
  const limit=world.size/2-.65;
  if(Math.abs(position.x)>limit-radius || Math.abs(position.z)>limit-radius)return true;
  return world.obstacles.some(obstacle=>
    Math.abs(position.x-obstacle.x)<obstacle.w/2+radius &&
    Math.abs(position.z-obstacle.z)<obstacle.d/2+radius
  );
}
export function activatePortal(exit) {
  exit.active=true;
  exit.ring.material=MATERIALS.portalOn;
  exit.beam.intensity=3;
}
export function updateWorld(world,elapsed,delta) {
  for(const item of world.crystals) {
    if(item.collected)continue;
    item.mesh.rotation.y+=delta*1.9;
    item.mesh.position.y=1.25+Math.sin(elapsed*2.5+item.position.x)*.16;
  }
  for(const enemy of world.enemies) {
    const travel=Math.sin(elapsed*enemy.speed+enemy.phase)*2.3;
    enemy.position.x=enemy.origin.x+(enemy.axis==='x'?travel:0);
    enemy.position.z=enemy.origin.z+(enemy.axis==='z'?travel:0);
    enemy.mesh.position.x=enemy.position.x;
    enemy.mesh.position.z=enemy.position.z;
    enemy.mesh.position.y=1.08+Math.sin(elapsed*3+enemy.phase)*.19;
    enemy.mesh.rotation.y+=delta*1.8;
  }
  world.exit.ring.rotation.z+=delta*(world.exit.active?2:.5);
}
