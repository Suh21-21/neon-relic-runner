export class SoundEngine {
  constructor() {
    this.context = null;
    this.muted = false;
  }
  unlock() {
    if (this.muted) return;
    if (!this.context) {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (Context) this.context = new Context();
    }
    if (this.context?.state === 'suspended') this.context.resume();
  }
  tone(frequency, duration = .14, waveform = 'sine', volume = .1, endFrequency = frequency) {
    if (!this.context || this.muted) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = waveform;
    oscillator.frequency.setValueAtTime(frequency, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(1, endFrequency), now + duration);
    gain.gain.setValueAtTime(volume, now);
    gain.gain.exponentialRampToValueAtTime(.001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }
  collect() {
    this.tone(650, .13, 'triangle', .07, 1050);
    setTimeout(() => this.tone(1070, .17, 'sine', .045, 1450), 60);
  }
  damage() { this.tone(160, .36, 'sawtooth', .07, 48); }
  jump() { this.tone(280, .14, 'sine', .055, 390); }
  win() {
    [440, 554, 659, 880].forEach((frequency, index) => {
      setTimeout(() => this.tone(frequency, .3, 'triangle', .055), index * 130);
    });
  }
}
