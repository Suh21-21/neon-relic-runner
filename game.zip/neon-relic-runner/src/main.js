import * as THREE from 'three';
import { SoundEngine } from './audio.js';
import { Player } from './player.js';
import { activatePortal, generateWorld, updateWorld } from './world.js';
import { distance2D, formatTime, smoothTowards } from './math.js';

const dom={
  container:document.getElementById('game'),
  overlay:document.getElementById('overlay'),
  title:document.getElementById('panel-title'),
  message:document.getElementById('panel-text'),
  record:document.getElementById('record'),
  button:document.getElementById('action'),
  level:document.getElementById('level'),
  relics:document.getElementById('relics'),
  health:document.getElementById('health'),
  timer:document.getElementById('timer'),
  toast:document.getElementById('toast')
};

const scene=new THREE.Scene();
scene.background=new THREE.Color(0x060c1c);
scene.fog=new THREE.FogExp2(0x080f24,.018);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setSize(window.innerWidth,window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;
dom.container.appendChild(renderer.domElement);
const camera=new THREE.PerspectiveCamera(54,window.innerWidth/window.innerHeight,.1,150);
camera.position.set(-10,14,16);
const ambient=new THREE.HemisphereLight(0x8eb8ff,0x17203f,1.8);
scene.add(ambient);
const sun=new THREE.DirectionalLight(0xa5d9ff,2.4);
sun.position.set(-8,18,8);
sun.castShadow=true;
sun.shadow.mapSize.set(1024,1024);
sun.shadow.camera.left=-28;
sun.shadow.camera.right=28;
sun.shadow.camera.top=28;
sun.shadow.camera.bottom=-28;
scene.add(sun);
const audio=new SoundEngine();
const keys=new Set();
let world=null;
let player=null;
let level=1;
let health=3;
let collected=0;
let elapsed=0;
let totalTime=0;
let state='menu';
let toastTimeout=null;
let lastFrame=performance.now();
let record=null;
try { record=Number(localStorage.getItem('neon-relic-runner-best'))||null; }catch{}

function toast(message) {
  dom.toast.textContent=message;
  dom.toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout=setTimeout(()=>dom.toast.classList.remove('show'),1300);
}
function showMenu(title,message,button) {
  dom.title.innerHTML=title;
  dom.message.textContent=message;
  dom.button.textContent=button;
  dom.record.textContent=`BEST TIME: ${record===null?'—':formatTime(record)}`;
  dom.overlay.classList.add('visible');
}
function refreshHud() {
  dom.level.textContent=level;
  dom.relics.textContent=`${collected}/${world?.crystals.length??0}`;
  dom.health.textContent='♥ '.repeat(health).trim()||'—';
  dom.timer.textContent=formatTime(totalTime);
}
function clearLevel() {
  if(world)scene.remove(world.group);
  if(player)player.dispose(scene);
  world=null;
  player=null;
}
function loadLevel(nextLevel) {
  clearLevel();
  level=nextLevel;
  health=3;
  collected=0;
  elapsed=0;
  world=generateWorld(scene,level);
  player=new Player(scene,world.start);
  state='playing';
  dom.overlay.classList.remove('visible');
  refreshHud();
  toast(`LEVEL ${level} — COLLECT THE RELICS`);
}
function start() {
  audio.unlock();
  if(state==='paused') {
    state='playing';
    dom.overlay.classList.remove('visible');
    return;
  }
  totalTime=0;
  loadLevel(1);
}
function pause() {
  if(state==='playing') {
    state='paused';
    showMenu('PAUSED','Take a moment. Your mission is saved until this page is closed.','RESUME');
  } else if(state==='paused') {
    start();
  }
}
function winLevel() {
  audio.win();
  if(level<3) {
    state='between';
    showMenu('LEVEL COMPLETE',`All ${world.crystals.length} relics secured! Prepare for a harder arena with additional sentinels.`,'NEXT LEVEL');
    return;
  }
  state='won';
  if(record===null||totalTime<record) {
    record=totalTime;
    try {localStorage.setItem('neon-relic-runner-best',String(record));}catch{}
  }
  showMenu('MISSION COMPLETE',`You completed all three arenas in ${formatTime(totalTime)}. Every relic recovered.`, 'PLAY AGAIN');
}
function lose() {
  state='lost';
  showMenu('MISSION FAILED',`The sentinels stopped you at level ${level}. Recover, then try a new route.`, 'RETRY');
}
function update(delta) {
  if(state!=='playing'||!world||!player)return;
  elapsed+=delta;
  totalTime+=delta;
  const input={
    up:keys.has('w')||keys.has('arrowup'),
    down:keys.has('s')||keys.has('arrowdown'),
    left:keys.has('a')||keys.has('arrowleft'),
    right:keys.has('d')||keys.has('arrowright'),
    sprint:keys.has('shift'),
    jump:keys.has(' ')
  };
  if(player.update(input,world,delta)) audio.jump();
  updateWorld(world,elapsed,delta);
  for(const item of world.crystals) {
    if(item.collected||distance2D(player.position,item.position)>.93)continue;
    item.collected=true;
    world.group.remove(item.mesh);
    collected++;
    audio.collect();
    toast(`RELIC SECURED ${collected}/${world.crystals.length}`);
    if(collected===world.crystals.length){activatePortal(world.exit);toast('PORTAL OPEN — REACH THE GOLD RING');}
  }
  for(const enemy of world.enemies) {
    if(player.invulnerable>0||player.airborne)continue;
    if(distance2D(player.position,enemy.position)<1.08) {
      player.damage();
      health--;
      audio.damage();
      toast('SENTINEL HIT — HEALTH LOST');
      if(health<=0){lose();return;}
    }
  }
  if(world.exit.active && distance2D(player.position,world.exit.position)<1.1)winLevel();
  const targetX=player.position.x-9;
  const targetY=15;
  const targetZ=player.position.z+13;
  camera.position.x=smoothTowards(camera.position.x,targetX,3.3,delta);
  camera.position.y=smoothTowards(camera.position.y,targetY,3.3,delta);
  camera.position.z=smoothTowards(camera.position.z,targetZ,3.3,delta);
  camera.lookAt(player.position.x,0,player.position.z);
  refreshHud();
}
function animate(now) {
  requestAnimationFrame(animate);
  const delta=Math.min((now-lastFrame)/1000,.05);
  lastFrame=now;
  update(delta);
  renderer.render(scene,camera);
}
window.addEventListener('keydown',event=>{
  const key=event.key.toLowerCase();
  if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(key))event.preventDefault();
  if(key==='p'&&!event.repeat)pause();
  keys.add(key);
});
window.addEventListener('keyup',event=>keys.delete(event.key.toLowerCase()));
window.addEventListener('blur',()=>{keys.clear();if(state==='playing')pause();});
window.addEventListener('resize',()=>{
  camera.aspect=window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth,window.innerHeight);
});
dom.button.addEventListener('click',()=>{
  if(state==='between'){audio.unlock();loadLevel(level+1);return;}
  start();
});
refreshHud();
requestAnimationFrame(animate);
