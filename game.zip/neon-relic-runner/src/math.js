export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
export function distance2D(a, b) {
  return Math.hypot(a.x - b.x, a.z - b.z);
}
export function formatTime(seconds) {
  const safe = Math.max(0, Math.floor(seconds));
  return `${Math.floor(safe / 60)}:${String(safe % 60).padStart(2, '0')}`;
}
export function seedRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value = (1664525 * value + 1013904223) >>> 0;
    return value / 4294967296;
  };
}
export function smoothTowards(current, target, response, delta) {
  return current + (target - current) * (1 - Math.exp(-response * delta));
}
export function hitCircle(a, ar, b, br) {
  return distance2D(a, b) < ar + br;
}
