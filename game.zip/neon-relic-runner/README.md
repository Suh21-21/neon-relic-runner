# Neon Relic Runner

A small, original browser-based 3D arcade game implemented with Three.js.

## Play

Requirements: Node.js 20.19+ (or newer compatible version), npm, and a modern desktop browser.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. Use **WASD** or **arrow keys** to move, **Shift** to sprint, **Space** to jump over sentinels, and **P** to pause. Collect the cyan crystals; when all are collected, reach the gold exit ring. Clear three levels to win. Best time is saved locally.

## Build and test

```bash
npm test
npm run build
npm run preview
```

## Project structure

- `src/main.js`: game lifecycle, rendering, controls, HUD, and progression
- `src/world.js`: procedural arena, crystals, moving enemies, portal, collisions
- `src/player.js`: player mesh, movement, jumping, temporary invulnerability
- `src/math.js`: deterministic, reusable math utilities
- `src/audio.js`: original procedural synthesized game cues
- `src/style.css`: responsive HUD, title and pause menu
- `tests/math.test.js`: Node's built-in unit tests

## Attribution and ownership

Game source produced with substantial AI assistance (ChatGPT, 2026). Do **not** present it as primarily human-written. The geometry, colors, environment, and audio are generated procedurally by the code; no third-party 3D models or audio samples ship with the project. Three.js, Vite, and their dependencies are third-party software under their own licences. The Google Fonts stylesheet is fetched at runtime; substitute a system font if desired.

## Development history

This distribution does not claim historical Git commits or ongoing human development. Real commits should reflect actual changes as they happen; never backdate commits to meet review requirements.

## Limitations and future improvements

- Desktop keyboard controls only; mobile touch controls could be added.
- Collision detection uses simple axis-aligned boxes and circles.
- No server-side leaderboard, authentication, or multiplayer.
- Enemies patrol along a single axis rather than pathfinding around obstacles.
- The environment is random but deterministic for each level.
